import xbmcaddon
MainBase = 'https://goo.gl/tZXFZF'
addon = xbmcaddon.Addon('plugin.video.TorrentBR')